package com.srivalli.student_grade_calculator;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button btn_result;
    EditText enNum1;
    EditText enNum2;
    EditText enNum3;
    EditText enNum4;
    EditText enNum5;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
            enNum1 = findViewById(R.id.enNum1);
            enNum2 = findViewById(R.id.enNum2);
            enNum3 = findViewById(R.id.enNum3);
            enNum4 = findViewById(R.id.enNum4);
            enNum5 = findViewById(R.id.enNum5);

            btn_result = findViewById(R.id.btn_result);
            result = findViewById(R.id.result);
            btn_result.setOnClickListener(v -> {

                int a = Integer.parseInt(enNum1.getText().toString());
                int b = Integer.parseInt(enNum2.getText().toString());
                int c = Integer.parseInt(enNum3.getText().toString());
                int d = Integer.parseInt(enNum4.getText().toString());
                int e = Integer.parseInt(enNum5.getText().toString());

                // Check marks
                if (a > 100 || b > 100 || c > 100 || d > 100 || e > 100) {
                    Toast.makeText(this, "Marks should not be above 100", Toast.LENGTH_SHORT).show();
                    return;
                }

                int total = a + b + c + d + e;

                double percentage = total / 5.0;

                if (percentage >= 90) {
                    result.setText("Total: " + total + "\nGrade: A+");
                }
                else if (percentage >= 80) {
                    result.setText("Total: " + total + "\nGrade: A");
                }
                else if (percentage >= 70) {
                    result.setText("Total: " + total + "\nGrade: B");
                }
                else if (percentage >= 60) {
                    result.setText("Total: " + total + "\nGrade: C");
                }
                else if (percentage >= 50) {
                    result.setText("Total: " + total + "\nGrade: D");
                }
                else {
                    result.setText("Total: " + total + "\nGrade: F");
                }
            });
        }
    }

