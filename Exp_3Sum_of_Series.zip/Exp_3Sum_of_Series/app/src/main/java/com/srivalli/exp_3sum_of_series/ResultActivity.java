package com.srivalli.exp_3sum_of_series;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    TextView tvValue;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Connect Java variables with XML views
        tvValue = findViewById(R.id.tvValue);
        result = findViewById(R.id.result);

        // Get the Intent
        Intent intent = getIntent();

        // Receive the data
        int n = intent.getIntExtra("Number", 0);
        double sum = intent.getDoubleExtra("Result", 0.0);

        // Display the values
        tvValue.setText(String.valueOf(n));
        result.setText(String.valueOf(sum));
    }
}