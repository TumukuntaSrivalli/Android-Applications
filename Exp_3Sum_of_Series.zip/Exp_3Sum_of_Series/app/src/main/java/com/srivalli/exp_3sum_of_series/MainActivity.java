package com.srivalli.exp_3sum_of_series;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button btn_sum;
    EditText et_number;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btn_sum = findViewById(R.id.btn_sum);
        et_number = findViewById(R.id.et_number);

        btn_sum.setOnClickListener(v->{
            String input = et_number.getText().toString().trim();

            if(input.isEmpty()){
                Toast.makeText(MainActivity.this, getString(R.string.error_empty_n),
                Toast.LENGTH_SHORT
            ).show();
            return;
        }

        int n =Integer.parseInt(input);
        if(n <= 0) {
            Toast.makeText(MainActivity.this, getString(R.string.error_positive_n),
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }
        //Calculate the Series
        double sum=0;
        for(int i = 1;i <= n;i++){
            sum = sum + (1.0/i);
        }
        // Explicit Intent
            Intent intent = new Intent( MainActivity.this, ResultActivity.class);

        intent.putExtra( "Number",n);
        intent.putExtra( "Result",sum);
        startActivity(intent);
        });
    }
}