package com.srivalli.basic_calculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    //create object
    EditText enNum1,enNum2;
    Button btnAdd,btnSub,btnMulti,btnDiv;
    TextView Result;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //bind UI with your java
        enNum1= findViewById(R.id.enNum1);
        enNum2= findViewById(R.id.enNum2);

        btnAdd =findViewById(R.id.btnAdd);
        btnSub =findViewById(R.id.btnSub);
        btnMulti =findViewById(R.id.btnMul);
        btnDiv =findViewById(R.id.btnDiv);

        Result =findViewById(R.id.Result);

        btnAdd.setOnClickListener(v -> calculate("+"));
        btnSub.setOnClickListener(v -> calculate("-"));
        btnMulti.setOnClickListener(v -> calculate("*"));
        btnDiv.setOnClickListener(v -> calculate("/"));
    }

    @SuppressLint("SetTextI18n")
    private void calculate(String operation) {
        String first = enNum1.getText().toString().trim();
        String second= enNum2.getText().toString().trim();
        if(first.isEmpty() || second.isEmpty()){
            Toast.makeText(this,"please enter both numbers",Toast.LENGTH_SHORT).show();
            return;
        }
        double num1 = Double.parseDouble(first);
        double num2 = Double.parseDouble(second);
        double answer = 0;

        switch (operation) {
            case "+":
                answer = num1 + num2;
                break;

            case "-":
                answer = num1 - num2;
                break;

            case "*":
                answer = num1 * num2;
                break;

            case "/":
                if(num2 == 0) {
                    Toast.makeText(this, "cannot divide by zero", Toast.LENGTH_SHORT).show();
                    return;
                }
                answer = num1 / num2;
                break;
        }
        Result.setText("Result:"+ answer);

    }
}