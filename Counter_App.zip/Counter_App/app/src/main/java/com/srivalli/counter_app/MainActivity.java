package com.srivalli.counter_app;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    int count =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Add Object
        Button btnCount;
        TextView textCount;
        Button btnReset;

        //2.Bind UI with Your Java Code
        btnCount  = findViewById(R.id.btnCount);
        textCount = findViewById(R.id.textCount);
        btnReset = findViewById(R.id.btnReset);

        //3.On listener
        btnCount.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                count++;
                textCount.setText(" " + count);
            }
        });
         btnReset.setOnClickListener(new View.OnClickListener(){
             @Override
             public void onClick(View v){
                 count = 0;
                 textCount.setText(" " + count);
             }
         });
    }
}