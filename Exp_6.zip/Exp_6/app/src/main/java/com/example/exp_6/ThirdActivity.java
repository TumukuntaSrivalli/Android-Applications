package com.example.exp_6;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class ThirdActivity extends AppCompatActivity {

    Button btnReadFile;
    TextView tvFileData;

    private static final String FILE_NAME = "employee_data.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.third_acitivity);

        btnReadFile = findViewById(R.id.btnReadFile);
        tvFileData = findViewById(R.id.tvFileData);

        btnReadFile.setOnClickListener(v -> readFile());
    }

    private void readFile() {

        try {

            FileInputStream fis =
                    openFileInput(FILE_NAME);

            BufferedReader reader =
                    new BufferedReader(
                            new InputStreamReader(fis)
                    );

            StringBuilder data =
                    new StringBuilder();

            String line;

            while ((line = reader.readLine()) != null) {

                data.append(line);
                data.append("\n");
            }

            reader.close();
            fis.close();

            tvFileData.setText(data.toString());

            Toast.makeText(
                    ThirdActivity.this,
                    "File read successfully",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    ThirdActivity.this,
                    "File not found. Please write the file first.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}
