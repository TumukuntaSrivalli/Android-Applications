package com.example.exp_6;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText etName, etDepartment;
    TextView tvDob;
    Button btnDate, btnSubmit;

    String selectedDob = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etDepartment = findViewById(R.id.etDepartment);
        tvDob = findViewById(R.id.tvDob);
        btnDate = findViewById(R.id.btnDate);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnDate.setOnClickListener(v -> {

            Calendar calendar = Calendar.getInstance();

            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog dialog = new DatePickerDialog(
                    MainActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {

                        selectedDob =
                                selectedDay + "/" +
                                        (selectedMonth + 1) + "/" +
                                        selectedYear;

                        tvDob.setText(
                                "Date of Birth: " + selectedDob
                        );
                    },
                    year,
                    month,
                    day
            );

            dialog.show();
        });

        btnSubmit.setOnClickListener(v -> {

            String name = etName.getText().toString().trim();
            String department = etDepartment.getText().toString().trim();

            if (name.isEmpty()) {
                etName.setError("Enter employee name");
                return;
            }

            if (department.isEmpty()) {
                etDepartment.setError("Enter department");
                return;
            }

            if (selectedDob.isEmpty()) {

                Toast.makeText(
                        MainActivity.this,
                        "Please select Date of Birth",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            Intent intent = new Intent(
                    MainActivity.this,
                    Second_Activity.class
            );

            intent.putExtra("name", name);
            intent.putExtra("department", department);
            intent.putExtra("dob", selectedDob);

            startActivity(intent);
        });
    }
}