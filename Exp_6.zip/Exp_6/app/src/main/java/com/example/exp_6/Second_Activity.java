package com.example.exp_6;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.util.Calendar;

public class Second_Activity extends AppCompatActivity {

    TextView tvName;
    TextView tvDepartment;
    TextView tvDob;
    TextView tvTime;

    EditText etProjectName;

    Button btnTime;
    Button btnWriteFile;
    Button btnNext;

    String name;
    String department;
    String dob;
    String selectedTime = "";

    private static final String FILE_NAME = "employee_data.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.second_activity);

        tvName = findViewById(R.id.tvName);
        tvDepartment = findViewById(R.id.tvDepartment);
        tvDob = findViewById(R.id.tvDob);
        tvTime = findViewById(R.id.tvTime);

        etProjectName = findViewById(R.id.etProjectName);

        btnTime = findViewById(R.id.btnTime);
        btnWriteFile = findViewById(R.id.btnWriteFile);
        btnNext = findViewById(R.id.btnNext);

        name = getIntent().getStringExtra("name");
        department = getIntent().getStringExtra("department");
        dob = getIntent().getStringExtra("dob");

        tvName.setText("Name: " + name);
        tvDepartment.setText("Department: " + department);
        tvDob.setText("Date of Birth: " + dob);

        btnTime.setOnClickListener(v -> {

            Calendar calendar = Calendar.getInstance();

            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);

            TimePickerDialog dialog = new TimePickerDialog(
                    Second_Activity.this,
                    (view, selectedHour, selectedMinute) -> {

                        String amPm =
                                selectedHour >= 12 ? "PM" : "AM";

                        int hour12 = selectedHour % 12;

                        if (hour12 == 0) {
                            hour12 = 12;
                        }

                        selectedTime = String.format(
                                "%02d:%02d %s",
                                hour12,
                                selectedMinute,
                                amPm
                        );

                        tvTime.setText(
                                "Time of Submission: " + selectedTime
                        );
                    },
                    hour,
                    minute,
                    false
            );

            dialog.show();
        });

        btnWriteFile.setOnClickListener(v -> writeFile());

        btnNext.setOnClickListener(v -> {

            Intent intent = new Intent(
                    Second_Activity.this,
                    ThirdActivity.class
            );

            startActivity(intent);
        });
    }

    private void writeFile() {

        String projectName =
                etProjectName.getText().toString().trim();

        if (projectName.isEmpty()) {
            etProjectName.setError("Enter project name");
            return;
        }

        if (selectedTime.isEmpty()) {

            Toast.makeText(
                    Second_Activity.this,
                    "Please select submission time",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String data =
                "Employee Name: " + name + "\n" +
                        "Department: " + department + "\n" +
                        "Date of Birth: " + dob + "\n" +
                        "Project Name: " + projectName + "\n" +
                        "Time of Submission: " + selectedTime;

        try {

            FileOutputStream fos =
                    openFileOutput(
                            FILE_NAME,
                            MODE_PRIVATE
                    );

            fos.write(data.getBytes());
            fos.close();

            Toast.makeText(
                    Second_Activity.this,
                    "File saved successfully",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    Second_Activity.this,
                    "Error saving file",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}