package com.srivalli.visitingapp;

import static java.util.List.*;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class second_layout extends AppCompatActivity {
    ArrayList<String> labels = new ArrayList<>(Arrays.asList("Name0","Mobile","Email","Course","Department",
            "Campus"));
    ArrayList<String> details = new ArrayList<>();
    ArrayList<String> display = new ArrayList<>();
    ArrayList<String> adapter;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_layout);

        ListView list = findViewById(R.id.listStudentDetails);

        String[] keys = {"NAME", "MOBILE", "EMAIL", "COURSE", "DEPARTMENT", "CAMPUS"};

        for(String key:keys)
            details.add(getIntent().getStringExtra(key));

        updateList();

        adapter = new ArrayList<String>(android.R.layout.simple_list_item_1);
        List.setAdapter(adapter);

        List.setOnItemClickListener(( p, v, pos, id)-> editData(pos));

    }

    private void updateList() {
    }
}
