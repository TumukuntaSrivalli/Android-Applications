package com.srivalli.greetingapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {
    TextView tvhello;
    Button btn_back;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);

        tvhello = findViewById(R.id.tvhello);
        btn_back = findViewById(R.id.btn_back);

        String Name = getIntent().getStringExtra("username");

        tvhello.setText("Hello," + Name + " ");
        btn_back.setOnClickListener(v -> finish());
    }
}