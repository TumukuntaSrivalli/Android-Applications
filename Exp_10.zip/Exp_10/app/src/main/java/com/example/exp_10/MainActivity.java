
package com.example.exp_10;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView statusText;
    private BroadcastReceiver airplaneReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        Button checkButton = findViewById(R.id.checkButton);

        airplaneReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_AIRPLANE_MODE_CHANGED
                        .equals(intent.getAction())) {

                    boolean enabled = intent.getBooleanExtra(
                            "state", false);

                    updateStatus(enabled);

                    Toast.makeText(context,
                            enabled ? "Airplane Mode ON"
                                    : "Airplane Mode OFF",
                            Toast.LENGTH_SHORT).show();
                }
            }
        };

        checkButton.setOnClickListener(v -> {
            boolean enabled = isAirplaneModeOn();
            updateStatus(enabled);
        });

        updateStatus(isAirplaneModeOn());
    }

    @SuppressLint("NewApi")
    @Override
    protected void onStart() {
        super.onStart();

        IntentFilter filter = new IntentFilter(
                Intent.ACTION_AIRPLANE_MODE_CHANGED);

        registerReceiver(airplaneReceiver, filter,
                Context.RECEIVER_EXPORTED);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(airplaneReceiver);
    }

    private boolean isAirplaneModeOn() {
        return Settings.Global.getInt(
                getContentResolver(),
                Settings.Global.AIRPLANE_MODE_ON, 0) == 1;
    }

    private void updateStatus(boolean enabled) {
        statusText.setText(enabled
                ? "Airplane Mode: ON"
                : "Airplane Mode: OFF");
    }
}
