package com.example.set_3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.example.set_3.second_activity;

public class MainActivity extends AppCompatActivity {

    EditText edtName;
    Button btnRecommend;
    Spinner spinnerGenre;

    String[] genres = {
            "Fiction", "Science Fiction",
            "Mystery", "Self-Help"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtName = findViewById(R.id.edtName);
        btnRecommend = findViewById(R.id.btnRecommend);
        spinnerGenre = findViewById(R.id.spinnerGenre);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                genres
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerGenre.setAdapter(adapter);

        btnRecommend.setOnClickListener(v -> {
            String name = edtName.getText().toString();
            String genre = spinnerGenre.getSelectedItem().toString();

            Intent intent = new Intent(
                    MainActivity.this, second_activity.class
            );

            intent.putExtra("Name", name);
            intent.putExtra("Genre", genre);

            startActivity(intent);
        });
    }
}