package com.example.set_3;

import android.os.Bundle;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.io.IOException;

public class SecondActivity extends AppCompatActivity {
    TextView txtHello, txtGenre, txtTitle, txtAuthor, txtDescription;
    ImageView imgCover;
    Button btnSave;
    WebView webView;

    String name, genre;
    String title, author, description;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);

        txtHello = findViewById(R.id.txtHello);
        txtGenre = findViewById(R.id.txtGenre);
        txtTitle = findViewById(R.id.txtTitle);
        txtAuthor = findViewById(R.id.txtAuthor);
        txtDescription = findViewById(R.id.txtDescription);

        imgCover = findViewById(R.id.imgCover);
        btnSave = findViewById(R.id.btnSave);
        webView = findViewById(R.id.webView);

        String name = getIntent().getStringExtra("name");
        String genre = getIntent().getStringExtra("genre");

        txtHello.setText("Hello " + name);
        txtGenre.setText("Genre: " + genre);

        if (genre.equals("Fiction")) {

            title = "The Alchemist";
            author = "Paulo Coelho";
            description = "A story about following your dreams.";

        } else if (genre.equals("Mystery")) {

            title = "The Hound of the Baskervilles";
            author = "Arthur Conan Doyle";
            description = "A famous Sherlock Holmes mystery.";

        } else if (genre.equals("Science Fiction")) {

            title = "Dune";
            author = "Frank Herbert";
            description = "A science fiction story about a desert planet.";

        } else {

            title = "Atomic Habits";
            author = "James Clear";
            description = "A book about building good habits.";

        }

        // Display recommendation
        txtTitle.setText(title);
        txtAuthor.setText("Author: " + author);
        txtDescription.setText(description);

        btnSave.setOnClickListener(v -> {

            String data = "Name: " + name +
                    "\nGenre: " + genre +
                    "\nBook: " + title +
                    "\nAuthor: " + author +
                    "\nDescription: " + description;

                try {
                    FileOutputStream fos = openFileOutput("book.txt",MODE_PRIVATE);
                    fos.write(data.getBytes());
                    fos.close();

                    Toast.makeText(this,"Saved file",Toast.LENGTH_SHORT).show();
                }
                catch (Exception e) {
                    Toast.makeText(this, "Error",Toast.LENGTH_SHORT).show();
                }
                String html = "<html><body>"+
                        "<h2>" + title + "</h2>" +
                        "<b>Author:</b> " + author + "<br>" +
                        "<b>Genre:</b> " + genre + "<br>" +
                        "<p>" + description + "</p>" +
                        "</body></html>";
                webView.loadData(html,"UTF-8","text/html");

    });
    }
}