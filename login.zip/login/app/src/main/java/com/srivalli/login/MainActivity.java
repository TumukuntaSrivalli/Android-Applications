package com.srivalli.login;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btn_login;
    EditText et_username;
    EditText et_password;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_login = findViewById(R.id.btn_login);
        et_username = findViewById(R.id.et_username);
        et_password = findViewById(R.id.et_password);
        btn_login.setOnClickListener(v -> {

            String name = et_username.getText().toString().trim();
            String password = et_password.getText().toString().trim();

            if (name.isEmpty()) {
                Toast.makeText(this,
                        "Enter the name",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.isEmpty()) {
                Toast.makeText(this,
                        "Enter the password",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(MainActivity.this, welcome.class
            );

            intent.putExtra("Name", name);
            intent.putExtra("Password", password);
            startActivity(intent);
        });
    }
}