package com.srivalli.login;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class welcome extends AppCompatActivity {

    TextView et_greeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.second_page);

        et_greeting = findViewById(R.id.et_greeting);

        Intent intent = getIntent();

        String name = intent.getStringExtra("Name");

        et_greeting.setText("Hello, " + name);
    }
}