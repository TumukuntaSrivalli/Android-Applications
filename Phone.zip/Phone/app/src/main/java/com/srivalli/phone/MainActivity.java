package com.srivalli.phone;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText num;
    Button zero,one,two,three,four,five,six,seven,eight,nine,btn_call;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        num = findViewById(R.id.num);
        zero = findViewById(R.id.zero);
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);
        five = findViewById(R.id.five);
        six = findViewById(R.id.six);
        seven = findViewById(R.id.seven);
        eight = findViewById(R.id.eight);
        nine = findViewById(R.id.nine);
        btn_call = findViewById(R.id.btn_call);

        zero.setOnClickListener(v -> num.append("0"));

        one.setOnClickListener(v -> num.append("1"));

        two.setOnClickListener(v -> num.append("2"));

        three.setOnClickListener(v -> num.append("3"));

        four.setOnClickListener(v -> num.append("4"));

        five.setOnClickListener(v -> num.append("5"));

        six.setOnClickListener(v -> num.append("6"));

        seven.setOnClickListener(v -> num.append("7"));

        eight.setOnClickListener(v -> num.append("8"));

        nine.setOnClickListener(v -> num.append("9"));

        // Call button
        btn_call.setOnClickListener(v -> {
            String number = num.getText().toString();

            Intent intent = new Intent(
                    Intent.ACTION_DIAL,
                    Uri.parse("tel: +91" + number)
            );
            startActivity(intent);
        });
    }
}