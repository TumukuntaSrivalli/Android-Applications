package com.srivalli.prime_number_checker;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    //Object
    Button btn_prime;
    TextView Result;
    EditText enNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Bind UI
        btn_prime = findViewById(R.id.btn_prime);
        Result = findViewById(R.id.Result);
        enNum = findViewById(R.id.enNum);

        btn_prime.setOnClickListener(v->{
            int n = Integer.parseInt(enNum.getText().toString());

            int count=0;
            for(int i=1;i<=n;i++){
                if(n%i == 0){
                    count++;
                }
            }
            if (count == 2) {
                Result.setText("Prime Number");
            } else {
                Result.setText("Not a Prime Number");
            }
        });
    }
}