package com.srivalli.exp_2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText Num;
    Button btnEven,btnOdd,btnFact;
    TextView Result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //bind UI with your java
        Num= findViewById(R.id.enNum);
        btnEven =findViewById(R.id.Even);
        btnOdd =findViewById(R.id.btnOdd);
        btnFact =findViewById(R.id.btnfactorial);

        Result =findViewById(R.id.Result);

        btnEven.setOnClickListener(v -> checkEven());

        btnOdd.setOnClickListener(v -> checkOdd());

        btnFact.setOnClickListener(v -> findFactorial());
    }

    @SuppressLint("SetTextI18n")
    private void checkEven() {
        String input = Num.getText().toString();

        if (input.isEmpty()) {
            Result.setText("Please enter a number");
            return;
        }

        int n = Integer.parseInt(input);

        if (n % 2 == 0)
            Result.setText("Even Number");
        else
            Result.setText("Not Even");
    }

    @SuppressLint("SetTextI18n")
    private void checkOdd() {
        String input = Num.getText().toString();

        if (input.isEmpty()) {
            Result.setText("Please enter a number");
            return;
        }

        int n = Integer.parseInt(input);

        if (n % 2 != 0)
            Result.setText("Odd Number");
        else
            Result.setText("Not Odd");
    }
    @SuppressLint("SetTextI18n")
    private void findFactorial() {
        String input = Num.getText().toString();

        if (input.isEmpty()) {
            Result.setText("Please enter a number");
            return;
        }

        int n = Integer.parseInt(input);

        long fact = 1;

        for (int i = 1; i <= n; i++) {
            fact *= i;
        }
        Result.setText("Factorial = " + fact);
    }
}