# Fix Google Maps Implementation and Lifecycle Errors

Fix and improve the Google Maps implementation in `Exp_8` by resolving missing `MapView` lifecycle methods, fixing hardcoded layout dimensions, updating dependencies, and adding runtime location permission handling.

## User Review Required

> [!IMPORTANT]
> - **MapView Lifecycle**: Added `onSaveInstanceState(Bundle outState)` to `MainActivity.java` to prevent map state loss on configuration changes.
> - **Layout Responsiveness**: Replaced hardcoded dimensions (`404dp`/`732dp`) in `activity_main.xml` with full constraint bounds (`0dp`/`match_constraint`).
> - **Runtime Permissions & Location**: Added runtime permission checks and enabled the "My Location" layer on `GoogleMap` for a complete mapping experience.

## Open Questions

- None. The proposed improvements address standard Google Maps best practices and lifecycle stability.

## Proposed Changes

### Map Implementation & Activity

#### [MODIFY] [MainActivity.java](file:///C:/Users/T . Srivalli/AndroidStudioProjects/Exp_8/app/src/main/java/com/example/exp_8/MainActivity.java)
- Implement `onSaveInstanceState(Bundle outState)` to forward state to `mapView`.
- Add runtime location permission request (Fine & Coarse location) and enable `mMap.setMyLocationEnabled(true)` safely when granted.

### Layout & UI

#### [MODIFY] [activity_main.xml](file:///C:/Users/T . Srivalli/AndroidStudioProjects/Exp_8/app/src/main/res/layout/activity_main.xml)
- Update `MapView` layout attributes from hardcoded `404dp`/`732dp` to `0dp` (`match_constraint`) with constraints attached to all parent edges for proper scaling across devices.

### Dependencies & Versioning

#### [MODIFY] [libs.versions.toml](file:///C:/Users/T . Srivalli/AndroidStudioProjects/Exp_8/gradle/libs.versions.toml)
- Update `playServicesMaps` to `20.1.0`.
- Add `play-services-location` version and library reference for location tracking.

#### [MODIFY] [build.gradle.kts](file:///C:/Users/T . Srivalli/AndroidStudioProjects/Exp_8/app/build.gradle.kts)
- Add `play-services-location` dependency.

## Verification Plan

### Automated Tests
- Run Gradle build (`app:assembleDebug`) to verify compilation and resource linking.

### Manual Verification
- Deploy to emulator or physical device.
- Verify that the map loads correctly centered on Hyderabad with the marker.
- Verify configuration changes (rotation) preserve map state without crashing.
- Verify location permission prompt and user location blue dot.
