package com.srivalli.exp_3_q2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button btn_browser,btn_google_maps,btn_calldialer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btn_browser=findViewById(R.id.btn_browser);
        btn_browser.setOnClickListener(v->{
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com"));
            startActivity(intent);
        });
        btn_google_maps=findViewById(R.id.btn_google_maps);
        btn_google_maps.setOnClickListener(v->{
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("geo:17.3850,78.4867?q=Hyderabad"));
            startActivity(intent);
        });
        btn_calldialer=findViewById(R.id.btn_calldialer);
        btn_calldialer.setOnClickListener(v->{
            Intent intent = new Intent(Intent.ACTION_DIAL,
                    Uri.parse("tel:+91 9874563210"));
            startActivity(intent);
        });
    }
}