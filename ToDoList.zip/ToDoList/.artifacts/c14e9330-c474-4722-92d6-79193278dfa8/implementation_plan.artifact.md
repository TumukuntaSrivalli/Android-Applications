# To-Do List App Fix and Implementation Plan

The objective is to fix all compilation errors, database syntax errors, layout bugs, and implement full To-Do List functionality (Add, Edit, Delete, Check/Uncheck completion status with SQLite persistence).

## User Review Required

> [!IMPORTANT]
> The app currently has broken imports, SQL syntax errors, invalid RecyclerView IDs, non-functional custom layout manager, and missing database integration in `MainActivity`. We will correct all these components to make the app fully functional.

## Proposed Changes

### Database & Models

#### [MODIFY] [Task.java](file:///C:/Users/T%20.%20Srivalli/AndroidStudioProjects/ToDoList/app/src/main/java/com/srivalli/to_dolist/Task.java)
- Add a secondary constructor `public Task(String taskName, boolean completed)` for newly created tasks before they have a database ID.

#### [MODIFY] [DatabaseHelper.java](file:///C:/Users/T%20.%20Srivalli/AndroidStudioProjects/ToDoList/app/src/main/java/com/srivalli/to_dolist/DatabaseHelper.java)
- Fix SQL string concatenation missing spaces (`CREATE TABLE`, `DROP TABLE IF EXISTS`, `SELECT * FROM`, column spacing).
- Rename `getALlTasks` to `getAllTasks`.

#### [DELETE] [ConstraintLayoutManager.java](file:///C:/Users/T%20.%20Srivalli/AndroidStudioProjects/ToDoList/app/src/main/java/com/srivalli/to_dolist/ConstraintLayoutManager.java)
- Remove unused/broken `ConstraintLayoutManager` and use standard `LinearLayoutManager`.

### Layouts

#### [MODIFY] [activity_main.xml](file:///C:/Users/T%20.%20Srivalli/AndroidStudioProjects/ToDoList/app/src/main/res/layout/activity_main.xml)
- Fix RecyclerView ID from `@+id/recyclerView Tasks` to `@+id/recyclerView`.
- Clean up FloatingActionButton constraints.

#### [MODIFY] [task_items.xml](file:///C:/Users/T%20.%20Srivalli/AndroidStudioProjects/ToDoList/app/src/main/res/layout/task_items.xml)
- Change root layout height from `match_parent` to `wrap_content`.

#### [MODIFY] [dialog_add_task.xml](file:///C:/Users/T%20.%20Srivalli/AndroidStudioProjects/ToDoList/app/src/main/res/layout/dialog_add_task.xml)
- Ensure EditText has proper width (`match_parent` with margins) and ID `@+id/etTask`.

### UI & Adapters

#### [MODIFY] [TaskAdapter.java](file:///C:/Users/T%20.%20Srivalli/AndroidStudioProjects/ToDoList/app/src/main/java/com/srivalli/to_dolist/TaskAdapter.java)
- Verify `OnTaskActionListener` integration and click handling for checkboxes, edit buttons, and delete buttons.

#### [MODIFY] [MainActivity.java](file:///C:/Users/T%20.%20Srivalli/AndroidStudioProjects/ToDoList/app/src/main/java/com/srivalli/to_dolist/MainActivity.java)
- Fix broken imports (`VERSION_CODES_FULL.R`, `kotlinx.coroutines.scheduling.Task`).
- Initialize `DatabaseHelper` and load tasks from SQLite into RecyclerView.
- Implement FloatingActionButton click listener to show "Add Task" dialog.
- Implement `TaskAdapter.OnTaskActionListener` callbacks for delete, status change, and edit.

## Verification Plan

### Automated Tests
- Build project using Gradle (`gradle_build("app:assembleDebug")`) to ensure all compilation errors are resolved.

### Manual Verification
- Verify app launches successfully, displays empty or populated task list.
- Test adding a task via FloatingActionButton dialog.
- Test checking/unchecking task completion.
- Test editing a task name.
- Test deleting a task.
