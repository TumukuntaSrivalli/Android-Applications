# Task Progress

- [x] Fix Task.java constructor
- [x] Fix DatabaseHelper.java SQL queries and method name
- [x] Delete unused ConstraintLayoutManager.java and ids.xml
- [x] Fix layouts (activity_main.xml, task_items.xml, dialog_add_task.xml)
- [x] Implement TaskAdapter and MainActivity logic with SQLite database and dialogs
- [x] Run Gradle build to verify compilation (`Build finished successfully`)
