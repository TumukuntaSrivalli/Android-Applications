package com.srivalli.to_dolist;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements TaskAdapter.OnTaskActionListener {
    RecyclerView recyclerView;
    FloatingActionButton floatingActionButton;
    ArrayList<Task> taskList;
    TaskAdapter adapter;
    DatabaseHelper databaseHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseHelper = new DatabaseHelper(this);
        floatingActionButton = findViewById(R.id.floatingActionButton);
        recyclerView = findViewById(R.id.recyclerView);

        taskList = new ArrayList<>();
        adapter = new TaskAdapter(taskList, this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        loadTasks();

        floatingActionButton.setOnClickListener(v -> showAddTaskDialog());
    }

    private void loadTasks() {
        taskList.clear();
        Cursor cursor = databaseHelper.getAllTasks();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                String taskName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TASK));
                int status = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_STATUS));
                taskList.add(new Task(id, taskName, status == 1));
            }
            cursor.close();
        }
        adapter.notifyDataSetChanged();
    }

    private void showAddTaskDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null);
        EditText etTask = view.findViewById(R.id.etTask);

        builder.setView(view)
                .setTitle("Add Task")
                .setPositiveButton("Add", (dialog, which) -> {
                    String taskText = etTask.getText().toString().trim();
                    if (!taskText.isEmpty()) {
                        databaseHelper.addTask(taskText);
                        loadTasks();
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }

    @Override
    public void onTaskDelete(int position) {
        Task task = taskList.get(position);
        databaseHelper.deleteTask(task.getId());
        loadTasks();
    }

    @Override
    public void onTaskStatusChange(int position, boolean isCompleted) {
        Task task = taskList.get(position);
        databaseHelper.updateTaskStatus(task.getId(), isCompleted);
        task.setCompleted(isCompleted);
    }

    @Override
    public void onTaskEdit(int position) {
        Task task = taskList.get(position);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null);
        EditText etTask = view.findViewById(R.id.etTask);
        etTask.setText(task.getTaskName());
        etTask.setSelection(etTask.getText().length());

        builder.setView(view)
                .setTitle("Edit Task")
                .setPositiveButton("Update", (dialog, which) -> {
                    String newText = etTask.getText().toString().trim();
                    if (!newText.isEmpty()) {
                        databaseHelper.updateTaskName(task.getId(), newText);
                        loadTasks();
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }
}
