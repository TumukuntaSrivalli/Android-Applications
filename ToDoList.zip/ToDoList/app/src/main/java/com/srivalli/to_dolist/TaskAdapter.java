package com.srivalli.to_dolist;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.srivalli.to_dolist.R;

import java.util.ArrayList;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private final ArrayList<Task> taskList;
    private final OnTaskActionListener listener;

    public interface OnTaskActionListener {
        void onTaskDelete(int position);
        void onTaskStatusChange(int position, boolean isCompleted);
        void onTaskEdit(int position);
    }

    public TaskAdapter(ArrayList<Task> taskList, OnTaskActionListener listener) {
        this.taskList = taskList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.task_items, parent, false);

        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {

        Task task = taskList.get(position);

        holder.Add_Task.setOnCheckedChangeListener(null);
        holder.Add_Task.setText(task.getTaskName());
        holder.Add_Task.setChecked(task.isCompleted());

        holder.Add_Task.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (listener != null) {
                listener.onTaskStatusChange(position, isChecked);
            }
        });

        holder.btn_delete.setOnClickListener(v -> {
            if (listener != null) {
                listener.onTaskDelete(position);
            }
        });

        holder.btn_Add.setOnClickListener(v -> {
            if (listener != null) {
                listener.onTaskEdit(position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    public static class TaskViewHolder extends RecyclerView.ViewHolder {

        CheckBox Add_Task;
        ImageButton btn_Add;
        ImageButton btn_delete;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);

            Add_Task = itemView.findViewById(R.id.Add_Task);
            btn_Add = itemView.findViewById(R.id.btn_Add);
            btn_delete = itemView.findViewById(R.id.btn_delete);
        }
    }
}