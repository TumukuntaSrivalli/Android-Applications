package com.srivalli.to_dolist;

import androidx.recyclerview.widget.RecyclerView;

public class ConstraintLayoutManager extends RecyclerView.LayoutManager {
    public ConstraintLayoutManager(MainActivity mainActivity) {
    }
}
