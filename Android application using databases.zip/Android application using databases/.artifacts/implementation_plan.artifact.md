# Implementation Plan - Android Application Using Databases (Exp_7)

## Problem Description
Develop an Android application using SQLite databases (Student Management System) that allows users to:
1. Insert student records (Roll Number, Name, Course).
2. View/Retrieve all stored student records.
3. Update existing student records.
4. Delete student records.

## Proposed Components & Changes

### Database Layer
- **`DBHelper.java`**: SQLiteOpenHelper managing the `Students` table (`roll` INTEGER PRIMARY KEY, `name` TEXT, `course` TEXT), along with CRUD operations (`insertStudent`, `getStudents`, `updateStudent`, `deleteStudent`).

### UI & Activity Layer
- **`MainActivity.java`**: Activity binding form inputs (`EditText` for roll, name, course), action buttons (Insert, View, Update, Delete), and output view (`TextView` / `ScrollView`), with input validation and Toast messaging.
- **`activity_main.xml`**: Scrollable layout containing form fields, action buttons, and result display area.

## Verification Plan

### Automated Tests
- Build verification: `cmd /c "set ANDROID_PREFS_ROOT=& gradlew.bat assembleDebug"`
- Unit tests: `cmd /c "set ANDROID_PREFS_ROOT=& gradlew.bat test"`
