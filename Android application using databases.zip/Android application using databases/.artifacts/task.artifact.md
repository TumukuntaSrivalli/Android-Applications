# Task List - Android Application Using Databases (Exp_7)

- [x] Implement SQLite Database Helper (`DBHelper.java`) <!-- id: 0 -->
- [x] Implement MainActivity CRUD logic and validation (`MainActivity.java`) <!-- id: 1 -->
- [x] Design responsive UI layout (`activity_main.xml`) <!-- id: 2 -->
- [x] Run build (`assembleDebug`) and test verification <!-- id: 3 -->
- [x] Create walkthrough report <!-- id: 4 -->
