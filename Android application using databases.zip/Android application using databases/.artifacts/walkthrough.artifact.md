# Walkthrough - Android Application Using Databases (Exp_7)

I have developed and verified the **Android Application Using Databases** (Student Management System) project.

## Implementation Overview

### 1. SQLite Database Helper (`DBHelper.java`)
- Extends `SQLiteOpenHelper`.
- Manages database `StudentDB` and table `Students` (`roll` INTEGER PRIMARY KEY, `name` TEXT, `course` TEXT).
- Implements full CRUD methods:
  - `insertStudent(int roll, String name, String course)`
  - `getStudents()` returning a `Cursor`
  - `updateStudent(int roll, String name, String course)`
  - `deleteStudent(int roll)`

### 2. Activity Logic (`MainActivity.java`)
- Binds inputs (`roll`, `name`, `course`), action buttons (`insert`, `view`, `update`, `delete`), and output `result` text view.
- Provides robust input validation (`validInput()`) and Toast feedback (`showMessage()`).
- Iterates through database cursors and displays formatted student records.

### 3. Responsive UI Layout (`activity_main.xml`)
- Built with a scrollable container (`ScrollView` + `LinearLayout`).
- Uses responsive widths (`match_parent`) and clean spacing / padding for all form inputs and action buttons.

## Verification Results
- **Build**: `assembleDebug` passed successfully (`BUILD SUCCESSFUL`).
- **Tests**: Unit tests (`test`) passed successfully.
