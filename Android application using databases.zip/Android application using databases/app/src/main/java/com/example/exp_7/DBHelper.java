package com.example.exp_7;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "StudentDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "Students";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Students (" +
                "roll INTEGER PRIMARY KEY, " +
                "name TEXT, " +
                "course TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Students");
        onCreate(db);
    }

    public boolean insertStudent(int roll,
                                 String name, String course) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("roll", roll);
        values.put("name", name);
        values.put("course", course);

        long result = db.insert(TABLE_NAME, null, values);
        return result != -1;
    }

    public Cursor getStudents() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM Students", null);
    }

    public boolean updateStudent(int roll,
                                 String name, String course) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("course", course);

        int result = db.update(TABLE_NAME, values,
                "roll = ?", new String[]{
                        String.valueOf(roll)
                });

        return result > 0;
    }

    public boolean deleteStudent(int roll) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(TABLE_NAME,
                "roll = ?", new String[]{
                        String.valueOf(roll)
                });

        return result > 0;
    }
}