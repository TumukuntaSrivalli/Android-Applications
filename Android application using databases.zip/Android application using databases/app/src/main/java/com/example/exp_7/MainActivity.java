package com.example.exp_7;

import android.app.Activity;
import android.os.Bundle;
import android.database.Cursor;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

public class MainActivity extends Activity {

    EditText roll, name, course;
    Button insert, view, update, delete;
    TextView result;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        roll = findViewById(R.id.roll);
        name = findViewById(R.id.name);
        course = findViewById(R.id.course);

        insert = findViewById(R.id.insert);
        view = findViewById(R.id.view);
        update = findViewById(R.id.update);
        delete = findViewById(R.id.delete);
        result = findViewById(R.id.result);

        db = new DBHelper(this);

        insert.setOnClickListener(v -> {
            if (!validInput()) return;

            boolean success = db.insertStudent(
                    Integer.parseInt(roll.getText().toString()),
                    name.getText().toString().trim(),
                    course.getText().toString().trim());

            showMessage(success, "Student inserted",
                    "Insertion failed");
        });

        view.setOnClickListener(v -> {
            Cursor cursor = db.getStudents();
            StringBuilder data = new StringBuilder();

            try {
                while (cursor.moveToNext()) {
                    data.append("Roll: ")
                            .append(cursor.getInt(0))
                            .append("\nName: ")
                            .append(cursor.getString(1))
                            .append("\nCourse: ")
                            .append(cursor.getString(2))
                            .append("\n\n");
                }
            } finally {
                cursor.close();
            }

            result.setText(data.length() == 0
                    ? "No student records found"
                    : data.toString());
        });

        update.setOnClickListener(v -> {
            if (!validInput()) return;

            boolean success = db.updateStudent(
                    Integer.parseInt(roll.getText().toString()),
                    name.getText().toString().trim(),
                    course.getText().toString().trim());

            showMessage(success, "Student updated",
                    "Student not found or update failed");
        });

        delete.setOnClickListener(v -> {
            if (roll.getText().toString().trim().isEmpty()) {
                roll.setError("Enter roll number");
                return;
            }

            boolean success = db.deleteStudent(
                    Integer.parseInt(roll.getText().toString()));

            showMessage(success, "Student deleted",
                    "Student not found");
        });
    }

    private boolean validInput() {
        if (roll.getText().toString().trim().isEmpty()
                || name.getText().toString().trim().isEmpty()
                || course.getText().toString().trim().isEmpty()) {
            Toast.makeText(this,
                    "Please fill in all fields",
                    Toast.LENGTH_SHORT).show();
            return false;
        }

        try {
            Integer.parseInt(roll.getText().toString().trim());
        } catch (NumberFormatException e) {
            roll.setError("Enter a valid integer");
            return false;
        }

        return true;
    }

    private void showMessage(boolean success,
                             String successMessage,
                             String errorMessage) {
        Toast.makeText(this,
                success ? successMessage : errorMessage,
                Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        db.close();
        super.onDestroy();
    }
}