# Daily Expenses Logger - Completion & Error Fixes Plan

The Daily Expenses Logger app is currently a skeleton project with an incomplete layout (`activity_main.xml` missing `EditText` inputs, typo in "Expenes"), no data model, and no implementation in `MainActivity.java`.

This plan outlines the steps to complete the app with full functionality: adding input fields, fixing layout and typos, implementing expense data handling, local storage / database or list persistence, and exporting data to Text and CSV files.

## User Review Required

> [!NOTE]
> The updated layout will replace absolute positioning (`android:layout_marginBottom="xxx dp"`) with robust `ConstraintLayout` constraints and add `EditText` input fields for Expense Title, Amount, and Note, along with a `RecyclerView` or list display for recorded expenses.

## Open Questions

- None. We will implement standard internal storage (SQLite / Room or Gson/File-based persistence) along with Text and CSV export.

## Proposed Changes

### App Components & Modules

#### [MODIFY] [activity_main.xml](file:///C:/Users/T . Srivalli/AndroidStudioProjects/DailyExpensesLogger/app/src/main/res/layout/activity_main.xml)
- Fix typo "Expenes" -> "Expense Name".
- Add `EditText` for Expense Title (`etExpenseName`).
- Add `EditText` for Amount (`etAmount` with decimal input type).
- Configure Spinner for Categories (Food, Transport, Shopping, Bills, Entertainment, Other).
- Add `EditText` for Note (`etNote`).
- Add `RecyclerView` or `ListView` to display logged expenses.
- Re-anchor buttons (`Save Data`, `File Text`, `File csv`) cleanly using `ConstraintLayout`.

#### [NEW] [Expense.java](file:///C:/Users/T . Srivalli/AndroidStudioProjects/DailyExpensesLogger/app/src/main/java/com/example/dailyexpenseslogger/Expense.java)
- Data model representing an expense entry (id, title, amount, category, note, date).

#### [NEW] [ExpenseAdapter.java](file:///C:/Users/T . Srivalli/AndroidStudioProjects/DailyExpensesLogger/app/src/main/java/com/example/dailyexpenseslogger/ExpenseAdapter.java)
- Adapter to display expenses in RecyclerView.

#### [NEW] [item_expense.xml](file:///C:/Users/T . Srivalli/AndroidStudioProjects/DailyExpensesLogger/app/src/main/res/layout/item_expense.xml)
- Layout for individual expense items in the list.

#### [MODIFY] [MainActivity.java](file:///C:/Users/T . Srivalli/AndroidStudioProjects/DailyExpensesLogger/app/src/main/java/com/example/dailyexpenseslogger/MainActivity.java)
- Initialize UI components (EditTexts, Spinner, Buttons, RecyclerView).
- Handle input validation and saving expenses to local storage (SharedPreferences / JSON / internal storage).
- Implement export to Text file (`.txt`) feature.
- Implement export to CSV file (`.csv`) feature.
- Show status toasts and update the expense list dynamically.

## Verification Plan

### Automated Tests
- Run Gradle build (`app:assembleDebug`) to ensure clean compilation without errors.

### Manual Verification
- Deploy app on emulator/device.
- Enter an expense name, amount, select category, add a note, and tap "Save Data".
- Verify expense appears in the list and total updates.
- Tap "File Text" and "File csv" to verify export functionality.
