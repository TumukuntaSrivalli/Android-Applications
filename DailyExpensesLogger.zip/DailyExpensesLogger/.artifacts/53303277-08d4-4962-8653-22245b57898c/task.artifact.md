# Task List

- [x] Create Expense model class (`Expense.java`)
- [x] Create item layout (`item_expense.xml`) and RecyclerView adapter (`ExpenseAdapter.java`)
- [x] Update `activity_main.xml` with input fields (`EditText`s), categories Spinner, and RecyclerView
- [x] Implement business logic in `MainActivity.java` (saving expenses, local storage, text & CSV file exports)
- [x] Build and verify app compilation and functionality
- [x] Create walkthrough artifact
