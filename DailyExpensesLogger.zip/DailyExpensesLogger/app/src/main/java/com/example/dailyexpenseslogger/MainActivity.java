package com.example.dailyexpenseslogger;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private EditText etExpenseTitle, etAmount, etNote;
    private Spinner spinnerCategory;
    private RecyclerView recyclerViewExpenses;
    private ExpenseAdapter expenseAdapter;
    private List<Expense> expenseList;

    private static final String PREF_FILE_NAME = "expenses_data.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etExpenseTitle = findViewById(R.id.etExpenseTitle);
        etAmount = findViewById(R.id.etAmount);
        etNote = findViewById(R.id.etNote);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        recyclerViewExpenses = findViewById(R.id.recyclerViewExpenses);

        Button btnSave = findViewById(R.id.btn_save);
        Button btnText = findViewById(R.id.btn_text);
        Button btnCsv = findViewById(R.id.btn_csv);

        // Setup Category Spinner
        String[] categories = {"Food", "Transport", "Utilities", "Shopping", "Entertainment", "Other"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        // Setup RecyclerView
        expenseList = new ArrayList<>();
        loadExpenses();
        expenseAdapter = new ExpenseAdapter(expenseList);
        recyclerViewExpenses.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewExpenses.setAdapter(expenseAdapter);

        // Button Listeners
        btnSave.setOnClickListener(v -> saveExpense());
        btnText.setOnClickListener(v -> exportToTextFile());
        btnCsv.setOnClickListener(v -> exportToCsvFile());
    }

    private void saveExpense() {
        String title = etExpenseTitle.getText().toString().trim();
        String amountStr = etAmount.getText().toString().trim();
        String category = spinnerCategory.getSelectedItem().toString();
        String note = etNote.getText().toString().trim();

        if (title.isEmpty()) {
            etExpenseTitle.setError("Please enter expense title");
            etExpenseTitle.requestFocus();
            return;
        }

        if (amountStr.isEmpty()) {
            etAmount.setError("Please enter amount");
            etAmount.requestFocus();
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
            if (amount <= 0) {
                etAmount.setError("Amount must be greater than zero");
                etAmount.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            etAmount.setError("Invalid amount format");
            etAmount.requestFocus();
            return;
        }

        String id = UUID.randomUUID().toString();
        String date = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());

        Expense expense = new Expense(id, title, amount, category, note.isEmpty() ? "-" : note, date);
        expenseList.add(0, expense);
        saveExpensesToFile();
        expenseAdapter.notifyItemInserted(0);
        recyclerViewExpenses.scrollToPosition(0);

        // Clear input fields
        etExpenseTitle.setText("");
        etAmount.setText("");
        etNote.setText("");
        spinnerCategory.setSelection(0);

        Toast.makeText(this, "Expense saved successfully!", Toast.LENGTH_SHORT).show();
    }

    private void saveExpensesToFile() {
        try {
            JSONArray jsonArray = new JSONArray();
            for (Expense exp : expenseList) {
                JSONObject obj = new JSONObject();
                obj.put("id", exp.getId());
                obj.put("title", exp.getTitle());
                obj.put("amount", exp.getAmount());
                obj.put("category", exp.getCategory());
                obj.put("note", exp.getNote());
                obj.put("date", exp.getDate());
                jsonArray.put(obj);
            }

            File file = new File(getFilesDir(), PREF_FILE_NAME);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(jsonArray.toString().getBytes());
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadExpenses() {
        try {
            File file = new File(getFilesDir(), PREF_FILE_NAME);
            if (!file.exists()) return;

            FileInputStream fis = new FileInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();
            fis.close();

            JSONArray jsonArray = new JSONArray(sb.toString());
            expenseList.clear();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                Expense exp = new Expense(
                        obj.getString("id"),
                        obj.getString("title"),
                        obj.getDouble("amount"),
                        obj.getString("category"),
                        obj.getString("note"),
                        obj.getString("date")
                );
                expenseList.add(exp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void exportToTextFile() {
        if (expenseList.isEmpty()) {
            Toast.makeText(this, "No expenses to export", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            File file = new File(getExternalFilesDir(null), "DailyExpenses.txt");
            FileOutputStream fos = new FileOutputStream(file);
            StringBuilder sb = new StringBuilder();
            sb.append("=== DAILY EXPENSES REPORT ===\n\n");
            double total = 0;
            for (Expense exp : expenseList) {
                sb.append("Title: ").append(exp.getTitle()).append("\n");
                sb.append("Amount: ₹").append(String.format(Locale.getDefault(), "%.2f", exp.getAmount())).append("\n");
                sb.append("Category: ").append(exp.getCategory()).append("\n");
                sb.append("Note: ").append(exp.getNote()).append("\n");
                sb.append("Date: ").append(exp.getDate()).append("\n");
                sb.append("-----------------------------\n");
                total += exp.getAmount();
            }
            sb.append("\nTOTAL EXPENSES: ₹").append(String.format(Locale.getDefault(), "%.2f", total)).append("\n");

            fos.write(sb.toString().getBytes());
            fos.close();

            Toast.makeText(this, "Exported Text to: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to export text file", Toast.LENGTH_SHORT).show();
        }
    }

    private void exportToCsvFile() {
        if (expenseList.isEmpty()) {
            Toast.makeText(this, "No expenses to export", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            File file = new File(getExternalFilesDir(null), "DailyExpenses.csv");
            FileOutputStream fos = new FileOutputStream(file);
            StringBuilder sb = new StringBuilder();
            sb.append("Title,Amount,Category,Note,Date\n");
            for (Expense exp : expenseList) {
                sb.append("\"").append(exp.getTitle().replace("\"", "\"\"")).append("\",");
                sb.append(exp.getAmount()).append(",");
                sb.append("\"").append(exp.getCategory()).append("\",");
                sb.append("\"").append(exp.getNote().replace("\"", "\"\"")).append("\",");
                sb.append("\"").append(exp.getDate()).append("\"\n");
            }

            fos.write(sb.toString().getBytes());
            fos.close();

            Toast.makeText(this, "Exported CSV to: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to export CSV file", Toast.LENGTH_SHORT).show();
        }
    }
}
