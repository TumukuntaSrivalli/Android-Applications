package com.example.dailyexpenseslogger;

import java.io.Serializable;

public class Expense implements Serializable {
    private String id;
    private String title;
    private double amount;
    private String category;
    private String note;
    private String date;

    public Expense(String id, String title, double amount, String category, String note, String date) {
        this.id = id;
        this.title = title;
        this.amount = amount;
        this.category = category;
        this.note = note;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public double getAmount() {
        return amount;
    }

    public String getCategory() {
        return category;
    }

    public String getNote() {
        return note;
    }

    public String getDate() {
        return date;
    }
}
